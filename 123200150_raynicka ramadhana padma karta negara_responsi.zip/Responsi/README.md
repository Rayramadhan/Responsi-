membuat pengelolaan data mahasiswa menggunakan mysql dan Java
disini adalah latihan membuat pengelolaan data mahasiswa dengan cara crud
